import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.html',
  styleUrls: ['./signup.scss'],
})
export class Signup {
  email: string = '';
  username: string = '';
  password: string = '';
  confirmPassword: string = '';
  isLoading: boolean = false;
  error: string = '';
  success: string = '';
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(private router: Router) {}

  onSubmit(form: NgForm) {
    if (!form.valid) return;

    if (this.password !== this.confirmPassword) {
      this.error = 'Las contraseñas no coinciden';
      return;
    }

    this.error = '';
    this.success = '';
    this.isLoading = true;

    // Simulate API call
    setTimeout(() => {
      const credentials = {
        email: this.email,
        username: this.username,
        password: this.password,
      };
      console.log('Signup attempt', credentials);

      // TODO: Replace with actual backend call
      // this.authService.register(credentials).subscribe(
      //   (response) => {
      //     this.isLoading = false;
      //     this.success = 'Cuenta creada exitosamente. Redirigiendo...';
      //     setTimeout(() => this.router.navigate(['/login']), 1500);
      //   },
      //   (error) => {
      //     this.isLoading = false;
      //     this.error = error.error.message || 'Error al crear la cuenta';
      //   }
      // );

      this.isLoading = false;
      this.success = 'Cuenta creada exitosamente. Redirigiendo...';
      setTimeout(() => this.router.navigate(['/login']), 1500);
    }, 1500);
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }
}
