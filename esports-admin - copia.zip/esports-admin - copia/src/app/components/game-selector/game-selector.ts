import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './game-selector.html',
  styleUrls: ['./game-selector.scss'],
})
export class GameSelector {
  games = [
    {
      id: 'lol',
      name: 'League of Legends',
      icon: '/assets/components/login/lol.png',
      route: '/dashboard/lol',
      color: '#0e8b95',
    },
    {
      id: 'valorant',
      name: 'Valorant',
      icon: '/assets/components/login/valorant.png',
      route: '/dashboard/valorant',
      color: '#ff4655',
    },
    {
      id: 'inazuma',
      name: 'Inazuma Eleven VR',
      icon: '/assets/components/login/inazuma.png',
      route: '/dashboard/inazuma',
      color: '#ffa500',
    },
  ];

  selectedGame: string | null = null;

  constructor(private router: Router) {}

  selectGame(gameId: string) {
    this.selectedGame = gameId;
    const game = this.games.find((g) => g.id === gameId);
    if (game) {
      setTimeout(() => {
        this.router.navigate([game.route]);
      }, 600);
    }
  }

  logout() {
    this.router.navigate(['/login']);
  }
}
