import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './forgot-password.html',
  styleUrls: ['./forgot-password.scss'],
})
export class ForgotPassword {
  email: string = '';
  isLoading: boolean = false;
  error: string = '';
  success: string = '';
  step: 'email' | 'code' | 'reset' = 'email';
  code: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(private router: Router) {}

  // Step 1: Send reset email
  onSubmitEmail(form: NgForm) {
    if (!form.valid) return;

    this.error = '';
    this.success = '';
    this.isLoading = true;

    setTimeout(() => {
      console.log('Reset email sent to:', this.email);
      this.isLoading = false;
      this.success = 'Se envió un código de recuperación a tu email';
      setTimeout(() => {
        this.step = 'code';
        this.success = '';
      }, 1500);
    }, 1500);
  }

  // Step 2: Verify code
  onSubmitCode(form: NgForm) {
    if (!form.valid) return;

    this.error = '';
    this.success = '';
    this.isLoading = true;

    setTimeout(() => {
      if (this.code.length === 6) {
        console.log('Code verified:', this.code);
        this.isLoading = false;
        this.success = 'Código verificado correctamente';
        setTimeout(() => {
          this.step = 'reset';
          this.success = '';
        }, 1500);
      } else {
        this.isLoading = false;
        this.error = 'El código debe tener 6 dígitos';
      }
    }, 1500);
  }

  // Step 3: Reset password
  onSubmitReset(form: NgForm) {
    if (!form.valid) return;

    if (this.newPassword !== this.confirmPassword) {
      this.error = 'Las contraseñas no coinciden';
      return;
    }

    this.error = '';
    this.success = '';
    this.isLoading = true;

    setTimeout(() => {
      console.log('Password reset for:', this.email);
      this.isLoading = false;
      this.success = 'Contraseña actualizada exitosamente. Redirigiendo...';
      setTimeout(() => {
        this.router.navigate(['/login']);
      }, 1500);
    }, 1500);
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  goBackStep() {
    if (this.step === 'code') {
      this.step = 'email';
      this.code = '';
      this.error = '';
      this.success = '';
    } else if (this.step === 'reset') {
      this.step = 'code';
      this.newPassword = '';
      this.confirmPassword = '';
      this.error = '';
      this.success = '';
    }
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }
}
