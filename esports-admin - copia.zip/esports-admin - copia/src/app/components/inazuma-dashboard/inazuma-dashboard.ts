import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TeamDetailComponent } from './team-detail/team-detail';

interface Player {
  id: string;
  name: string;
}

interface Team {
  id: string;
  name: string;
  logo: string;
  division: string;
  players: Player[];
  wins: number;
  losses: number;
}

interface Tournament {
  id: string;
  name: string;
  status: string;
  participants: number;
  startDate: string;
}

@Component({
  selector: 'app-inazuma-dashboard',
  standalone: true,
  imports: [CommonModule, TeamDetailComponent],
  templateUrl: './inazuma-dashboard.html',
  styleUrls: ['./inazuma-dashboard.scss'],
})
export class InazumaDashboard implements OnInit {
  activeTab: 'libre' | 'equipos' | 'torneos' = 'libre';
  selectedTeam: Team | null = null;

  freePlayers: Player[] = [];
  teams: Team[] = [];
  tournaments: Tournament[] = [];

  constructor(private router: Router) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    // Datos de ejemplo - reemplazar con llamadas a API
    this.freePlayers = [
      { id: '1', name: 'Hiroto Kira' },
      { id: '2', name: 'Ryo Ishizaki' },
      { id: '3', name: 'Daichi Sawamura' },
      { id: '4', name: 'Kazuto Sawada' },
      { id: '5', name: 'Joji Hattori' },
      { id: '6', name: 'Seiichi Okano' },
    ];

    this.teams = [
      {
        id: 'raimon',
        name: 'Raimon FC',
        logo: 'https://via.placeholder.com/300x300/0e8b95/ffffff?text=Raimon',
        division: 'División Elite',
        players: [
          { id: '101', name: 'Mamoru Endou' },
          { id: '102', name: 'Shuya Gouenji' },
          { id: '103', name: 'Kazemaru Ichirouta' },
          { id: '104', name: 'Shirou Fubuki' },
          { id: '105', name: 'Haruna Otonashi' },
        ],
        wins: 12,
        losses: 2,
      },
      {
        id: 'kidokawa',
        name: 'Kidokawa Seishuu',
        logo: 'https://via.placeholder.com/300x300/ff4655/ffffff?text=Kidokawa',
        division: 'División A',
        players: [
          { id: '201', name: 'Akira Ramen' },
          { id: '202', name: 'Haruto Azuma' },
          { id: '203', name: 'Takuto Yamamoto' },
          { id: '204', name: 'Hikaru Naruhaya' },
        ],
        wins: 9,
        losses: 5,
      },
      {
        id: 'teikoku',
        name: 'Teikoku Gakuen',
        logo: 'https://via.placeholder.com/300x300/ffa500/ffffff?text=Teikoku',
        division: 'División A',
        players: [
          { id: '301', name: 'Toramaru Todoroki' },
          { id: '302', name: 'Kyosuke Tobitaka' },
          { id: '303', name: 'Yuto Karino' },
        ],
        wins: 11,
        losses: 3,
      },
      {
        id: 'hakuren',
        name: 'Hakuren Academy',
        logo: 'https://via.placeholder.com/300x300/00d4ff/ffffff?text=Hakuren',
        division: 'División B',
        players: [
          { id: '401', name: 'Shiro Toramaru' },
          { id: '402', name: 'Rei Kiyama' },
          { id: '403', name: 'Jiro Totsuka' },
        ],
        wins: 7,
        losses: 7,
      },
    ];

    this.tournaments = [
      {
        id: 'nationals',
        name: 'Campeonato Nacional Inazuma',
        status: 'En curso',
        participants: 32,
        startDate: '2026-02-01',
      },
      {
        id: 'regional',
        name: 'Torneo Regional',
        status: 'En curso',
        participants: 24,
        startDate: '2026-02-10',
      },
      {
        id: 'friendly',
        name: 'Liga Amistosa',
        status: 'Por comenzar',
        participants: 18,
        startDate: '2026-03-01',
      },
    ];
  }

  switchTab(tab: 'libre' | 'equipos' | 'torneos') {
    this.activeTab = tab;
    this.selectedTeam = null;
  }

  selectTeam(team: Team) {
    this.selectedTeam = team;
  }

  closeTeamDetail() {
    this.selectedTeam = null;
  }

  backToSelector() {
    this.router.navigate(['/selector']);
  }
}
