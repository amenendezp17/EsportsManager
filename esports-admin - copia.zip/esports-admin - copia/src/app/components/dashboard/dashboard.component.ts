import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class DashboardComponent implements OnInit {
  usuarios: any[] = [];

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.dataService.getUsuarios().subscribe(
      (data: any) => {
        this.usuarios = data;
        console.log('Usuarios recibidos:', data);
      },
      (error: any) => console.error('Error al obtener usuarios:', error)
    );
  }
}