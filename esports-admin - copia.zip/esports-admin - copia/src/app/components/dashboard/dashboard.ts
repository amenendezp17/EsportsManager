import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { InazumaDashboard } from '../inazuma-dashboard/inazuma-dashboard';
import { ValorantDashboard } from '../valorant-dashboard/valorant-dashboard';
import { LolDashboard } from '../lol-dashboard/lol-dashboard';
import { ProfileModalComponent } from '../profile-modal/profile-modal';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, InazumaDashboard, ValorantDashboard, LolDashboard, ProfileModalComponent],
  template: `
    <div class="dashboard-wrapper">
      <div class="top-bar">
        <button class="profile-btn" (click)="showProfile = true" title="Ver perfil">
          👤 Perfil
        </button>
        <button class="logout-btn" (click)="logout()" title="Cerrar sesión">
          ⏻️
        </button>
      </div>
      
      <div [ngSwitch]="gameId">
        <app-inazuma-dashboard *ngSwitchCase="'inazuma'"></app-inazuma-dashboard>
        <app-valorant-dashboard *ngSwitchCase="'valorant'"></app-valorant-dashboard>
        <app-lol-dashboard *ngSwitchCase="'lol'"></app-lol-dashboard>
      <div *ngSwitchDefault class="dashboard">
        <div class="dashboard-header">
          <h1>{{ gameTitle }}</h1>
          <button (click)="backToSelector()" class="back-btn">← Atrás</button>
        </div>
        <div class="dashboard-content">
          <p>Panel de gestión de {{ gameTitle }}</p>
          <p style="font-size: 12px; color: #b1b3cc; margin-top: 20px;">
            Aquí irá el contenido específico del dashboard para {{ gameTitle }}
          </p>
        </div>
      </div>
    </div>

    <app-profile-modal 
      *ngIf="showProfile"
      [user]="currentUser"
      (close)="showProfile = false"
    ></app-profile-modal>
    </div>
  `,
  styles: [`
    .dashboard-wrapper {
      position: relative;
      width: 100%;
      height: 100vh;
    }

    .top-bar {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1500;
      display: flex;
      gap: 15px;
      align-items: center;
    }

    .profile-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      background: linear-gradient(135deg, #0e8b95 0%, #1ca3ad 100%);
      border: none;
      color: #fff;
      padding: 12px 20px;
      border-radius: 12px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(14, 139, 149, 0.3);
      font-family: inherit;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .profile-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(14, 139, 149, 0.4);
    }

    .profile-btn:active {
      transform: translateY(0);
    }

    .logout-btn {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #ff4655 0%, #ff6b7a 100%);
      border: none;
      color: #fff;
      font-size: 24px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(255, 70, 85, 0.3);
      font-family: inherit;
    }

    .logout-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(255, 70, 85, 0.4);
    }

    .logout-btn:active {
      transform: translateY(0);
    }
    
    .dashboard {
      width: 100%;
      height: 100vh;
      background: linear-gradient(135deg, #0f0f1e 0%, #1a1a2e 100%);
      display: flex;
      flex-direction: column;
      color: #ffffff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
    }

    .dashboard-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 32px 48px;
      background: rgba(7, 16, 168, 0.2);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);

      h1 {
        margin: 0;
        font-size: 28px;
        font-weight: 700;
      }
    }

    .back-btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #ffffff;
      padding: 10px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      font-family: inherit;
      transition: all 0.3s ease;

      &:hover {
        background: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.3);
      }
    }

    .dashboard-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 48px;

      p {
        margin: 0;
        font-size: 18px;
        color: #b1b3cc;
      }
    }
  `]
})
export class Dashboard {
  gameId: string = '';
  gameTitle: string = '';
  showProfile = false;
  
  currentUser = {
    name: 'Alex Martínez',
    team: 'T1',
    game: 'League of Legends',
    winRate: 68,
    role: 'Jugador' as const,
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {
    const gameId = this.route.snapshot.paramMap.get('gameId');
    this.gameId = gameId || '';
    this.gameTitle = this.getGameTitle(gameId || '');
    this.updateUserData(gameId || '');
  }

  updateUserData(gameId: string) {
    const usersByGame: { [key: string]: any } = {
      lol: {
        name: 'Alex Martínez',
        team: 'T1',
        game: 'League of Legends',
        winRate: 68,
        role: 'Jugador' as const,
      },
      valorant: {
        name: 'Alex Martínez',
        team: 'Vanguard Esports',
        game: 'Valorant',
        winRate: 72,
        role: 'Jugador' as const,
      },
      inazuma: {
        name: 'Alex Martínez',
        team: 'Raimon FC',
        game: 'Inazuma Eleven VR',
        winRate: 75,
        role: 'Manager' as const,
      },
    };
    this.currentUser = usersByGame[gameId] || this.currentUser;
  }

  getGameTitle(gameId: string): string {
    const games: { [key: string]: string } = {
      lol: 'League of Legends',
      valorant: 'Valorant',
      inazuma: 'Inazuma Eleven VR',
    };
    return games[gameId] || 'Dashboard';
  }

  backToSelector() {
    this.router.navigate(['/selector']);
  }

  logout() {
    window.history.back();
  }
}

