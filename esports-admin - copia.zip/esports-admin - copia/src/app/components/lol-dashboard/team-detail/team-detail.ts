import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Player {
  id: string;
  name: string;
  role: 'TOP' | 'MID' | 'JUNGLA' | 'ADC' | 'SUPPORT';
}

interface Team {
  id: string;
  name: string;
  logo: string;
  division: string;
  players: Player[];
  wins: number;
  losses: number;
}

@Component({
  selector: 'app-lol-team-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-backdrop" (click)="onBackdropClick($event)">
      <div class="modal-content" *ngIf="team">
        <button class="close-btn" (click)="closeModal()">✕</button>
        
        <div class="team-header">
          <img [src]="team.logo" [alt]="team.name" class="team-logo">
          <div class="team-info">
            <h2 class="team-name">{{ team.name }}</h2>
            <p class="team-division">{{ team.division }}</p>
          </div>
        </div>

        <div class="stats-container">
          <div class="stat">
            <span class="stat-label">Victorias</span>
            <span class="stat-value">{{ team.wins }}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Derrotas</span>
            <span class="stat-value">{{ team.losses }}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Win Rate</span>
            <span class="stat-value">{{ winRate() }}%</span>
          </div>
        </div>

        <div class="roster-section">
          <h3>Plantilla</h3>
          <table class="roster-table">
            <thead>
              <tr>
                <th>Jugador</th>
                <th>Rol</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let player of team.players">
                <td class="player-name">{{ player.name }}</td>
                <td>
                  <span class="role-badge" [style.background-color]="getRoleColor(player.role)">
                    {{ player.role }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
      animation: fadeIn 0.3s ease-out;
    }

    .modal-content {
      background: linear-gradient(135deg, rgba(14, 139, 149, 0.15) 0%, rgba(28, 163, 173, 0.1) 100%);
      border: 2px solid rgba(28, 163, 173, 0.3);
      border-radius: 20px;
      padding: 40px;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      position: relative;
      backdrop-filter: blur(10px);
      box-shadow: 0 8px 32px 0 rgba(14, 139, 149, 0.2);
      animation: slideDown 0.4s ease-out;
    }

    .close-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background: none;
      border: none;
      font-size: 28px;
      color: #0e8b95;
      cursor: pointer;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: all 0.3s ease;
    }

    .close-btn:hover {
      background: rgba(14, 139, 149, 0.2);
      transform: rotate(90deg);
    }

    .team-header {
      display: flex;
      gap: 30px;
      margin-bottom: 30px;
      align-items: center;
    }

    .team-logo {
      width: 280px;
      height: 280px;
      object-fit: contain;
      border-radius: 15px;
      background: rgba(14, 139, 149, 0.1);
      padding: 10px;
      box-shadow: 0 4px 15px rgba(14, 139, 149, 0.2);
    }

    .team-info {
      flex: 1;
    }

    .team-name {
      font-size: 32px;
      font-weight: 700;
      background: linear-gradient(135deg, #0e8b95 0%, #1ca3ad 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin: 0 0 10px 0;
    }

    .team-division {
      font-size: 14px;
      color: rgba(255, 255, 255, 0.6);
      margin: 0;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .stats-container {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      margin-bottom: 30px;
    }

    .stat {
      background: rgba(14, 139, 149, 0.15);
      border: 1px solid rgba(28, 163, 173, 0.3);
      border-radius: 12px;
      padding: 15px;
      text-align: center;
      backdrop-filter: blur(5px);
      transition: all 0.3s ease;
    }

    .stat:hover {
      border-color: rgba(28, 163, 173, 0.6);
      background: rgba(14, 139, 149, 0.25);
      transform: translateY(-2px);
    }

    .stat-label {
      display: block;
      font-size: 12px;
      color: rgba(255, 255, 255, 0.6);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }

    .stat-value {
      display: block;
      font-size: 24px;
      font-weight: 700;
      color: #0e8b95;
    }

    .roster-section {
      margin-top: 30px;
    }

    .roster-section h3 {
      font-size: 18px;
      font-weight: 600;
      color: #fff;
      margin: 0 0 20px 0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .roster-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    .roster-table thead {
      background: rgba(14, 139, 149, 0.2);
      border-bottom: 2px solid rgba(28, 163, 173, 0.4);
    }

    .roster-table thead th {
      padding: 12px;
      text-align: left;
      font-weight: 600;
      font-size: 13px;
      color: #0e8b95;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .roster-table thead th:last-child {
      text-align: center;
    }

    .roster-table tbody tr {
      border-bottom: 1px solid rgba(28, 163, 173, 0.2);
      transition: all 0.3s ease;
    }

    .roster-table tbody tr:hover {
      background: rgba(14, 139, 149, 0.1);
    }

    .roster-table tbody tr:last-child {
      border-bottom: none;
    }

    .roster-table tbody td {
      padding: 14px 12px;
      color: rgba(255, 255, 255, 0.9);
      font-size: 14px;
    }

    .roster-table tbody td:last-child {
      text-align: center;
    }

    .player-name {
      font-weight: 500;
      color: #fff;
    }

    .role-badge {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #fff;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }

    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @media (max-width: 768px) {
      .modal-content {
        padding: 25px;
        width: 95%;
      }

      .team-header {
        flex-direction: column;
        gap: 20px;
      }

      .team-logo {
        width: 220px;
        height: 220px;
      }

      .team-name {
        font-size: 24px;
      }

      .stats-container {
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
      }

      .stat {
        padding: 12px;
      }

      .stat-value {
        font-size: 20px;
      }

      .roster-table thead th {
        padding: 10px;
        font-size: 12px;
      }

      .roster-table tbody td {
        padding: 10px;
        font-size: 13px;
      }
    }

    @media (max-width: 480px) {
      .modal-backdrop {
        padding: 20px;
      }

      .modal-content {
        padding: 20px;
        border-radius: 15px;
      }

      .team-logo {
        width: 180px;
        height: 180px;
      }

      .team-name {
        font-size: 20px;
      }

      .stats-container {
        gap: 8px;
      }

      .stat-label {
        font-size: 11px;
      }

      .stat-value {
        font-size: 18px;
      }

      .roster-table thead th {
        padding: 8px;
        font-size: 11px;
      }

      .roster-table tbody td {
        padding: 8px;
        font-size: 12px;
      }
    }
  `],
})
export class LolTeamDetailComponent {
  @Input() team!: Team;
  @Output() close = new EventEmitter<void>();

  winRate(): number {
    const total = this.team.wins + this.team.losses;
    return total > 0 ? Math.round((this.team.wins / total) * 100) : 0;
  }

  getRoleColor(role: string): string {
    const colors: { [key: string]: string } = {
      'TOP': '#FF6B6B',
      'JUNGLA': '#4ECDC4',
      'MID': '#FFE66D',
      'ADC': '#A8DADC',
      'SUPPORT': '#C7B3E5',
    };
    return colors[role] || '#0a66e6';
  }

  closeModal() {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }
}
