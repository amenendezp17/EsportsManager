import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LolTeamDetailComponent } from './team-detail/team-detail';

interface Player {
  id: string;
  name: string;
  role: 'TOP' | 'MID' | 'JUNGLA' | 'ADC' | 'SUPPORT';
}

interface Team {
  id: string;
  name: string;
  logo: string;
  division: string;
  players: Player[];
  wins: number;
  losses: number;
}

interface Tournament {
  id: string;
  name: string;
  status: string;
  participants: number;
  startDate: string;
}

@Component({
  selector: 'app-lol-dashboard',
  standalone: true,
  imports: [CommonModule, LolTeamDetailComponent],
  templateUrl: './lol-dashboard.html',
  styleUrls: ['./lol-dashboard.scss'],
})
export class LolDashboard implements OnInit {
  activeTab: 'libre' | 'equipos' | 'torneos' = 'libre';
  selectedTeam: Team | null = null;

  freePlayers: Player[] = [];
  teams: Team[] = [];
  tournaments: Tournament[] = [];

  constructor(private router: Router) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    // Datos de ejemplo - reemplazar con llamadas a API
    this.freePlayers = [
      { id: '1', name: 'Jaime León', role: 'TOP' },
      { id: '2', name: 'Sandra Rodríguez', role: 'MID' },
      { id: '3', name: 'Roberto Martín', role: 'JUNGLA' },
      { id: '4', name: 'Andrés García', role: 'ADC' },
      { id: '5', name: 'Marta Sánchez', role: 'SUPPORT' },
      { id: '6', name: 'Carlos Núñez', role: 'MID' },
    ];

    this.teams = [
      {
        id: 'g2',
        name: 'G2 Esports',
        logo: 'https://via.placeholder.com/300x300/0a66e6/ffffff?text=G2',
        division: 'División Elite',
        players: [
          { id: '101', name: 'Wunder', role: 'TOP' },
          { id: '102', name: 'Jankos', role: 'JUNGLA' },
          { id: '103', name: 'Caps', role: 'MID' },
          { id: '104', name: 'Rekkles', role: 'ADC' },
          { id: '105', name: 'Mikyx', role: 'SUPPORT' },
        ],
        wins: 18,
        losses: 2,
      },
      {
        id: 'fnatic',
        name: 'Fnatic',
        logo: 'https://via.placeholder.com/300x300/FF5500/ffffff?text=Fnatic',
        division: 'División Elite',
        players: [
          { id: '201', name: 'Bwipo', role: 'TOP' },
          { id: '202', name: 'Razork', role: 'JUNGLA' },
          { id: '203', name: 'Humanoid', role: 'MID' },
          { id: '204', name: 'Upset', role: 'ADC' },
          { id: '205', name: 'Hylissang', role: 'SUPPORT' },
        ],
        wins: 15,
        losses: 5,
      },
      {
        id: 'mad',
        name: 'MAD Lions',
        logo: 'https://via.placeholder.com/300x300/FFD700/000000?text=MAD',
        division: 'División A',
        players: [
          { id: '301', name: 'Armut', role: 'TOP' },
          { id: '302', name: 'Svenskeren', role: 'JUNGLA' },
          { id: '303', name: 'Nisqy', role: 'MID' },
          { id: '304', name: 'Comp', role: 'ADC' },
          { id: '305', name: 'Kaiser', role: 'SUPPORT' },
        ],
        wins: 12,
        losses: 8,
      },
      {
        id: 'rogue',
        name: 'Rogue',
        logo: 'https://via.placeholder.com/300x300/8B0000/ffffff?text=Rogue',
        division: 'División A',
        players: [
          { id: '401', name: 'Odoamne', role: 'TOP' },
          { id: '402', name: 'Inspired', role: 'JUNGLA' },
          { id: '403', name: 'Larssen', role: 'MID' },
          { id: '404', name: 'Comp', role: 'ADC' },
          { id: '405', name: 'trymbi', role: 'SUPPORT' },
        ],
        wins: 10,
        losses: 10,
      },
    ];

    this.tournaments = [
      {
        id: 'eu-lec',
        name: 'LEC Spring Split',
        status: 'En curso',
        participants: 10,
        startDate: '2026-01-17',
      },
      {
        id: 'worlds',
        name: 'League of Legends World Championship',
        status: 'Por comenzar',
        participants: 12,
        startDate: '2026-09-15',
      },
      {
        id: 'msi',
        name: 'Mid-Season Invitational',
        status: 'Por comenzar',
        participants: 8,
        startDate: '2026-05-01',
      },
    ];
  }

  switchTab(tab: 'libre' | 'equipos' | 'torneos') {
    this.activeTab = tab;
    this.selectedTeam = null;
  }

  selectTeam(team: Team) {
    this.selectedTeam = team;
  }

  closeTeamDetail() {
    this.selectedTeam = null;
  }

  backToSelector() {
    this.router.navigate(['/selector']);
  }

  getRoleColor(role: string): string {
    const colors: { [key: string]: string } = {
      'TOP': '#FF6B6B',
      'JUNGLA': '#4ECDC4',
      'MID': '#FFE66D',
      'ADC': '#A8DADC',
      'SUPPORT': '#C7B3E5',
    };
    return colors[role] || '#0a66e6';
  }
}
