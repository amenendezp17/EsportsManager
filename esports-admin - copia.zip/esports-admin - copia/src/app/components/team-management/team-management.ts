import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-team-management',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './team-management.html',
  styleUrls: ['./team-management.scss'],
})
export class TeamManagement {

}
