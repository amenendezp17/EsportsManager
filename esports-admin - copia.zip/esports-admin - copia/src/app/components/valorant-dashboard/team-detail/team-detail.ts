import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Player {
  id: string;
  name: string;
  elo: string;
  characterMain: string;
}

interface Team {
  id: string;
  name: string;
  logo: string;
  division: string;
  players: Player[];
  wins: number;
  losses: number;
}

@Component({
  selector: 'app-valorant-team-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './team-detail.html',
  styleUrls: ['./team-detail.scss'],
})
export class ValorantTeamDetailComponent {
  @Input() team!: Team;
  @Output() close = new EventEmitter<void>();

  winRate(): number {
    const total = this.team.wins + this.team.losses;
    return total > 0 ? Math.round((this.team.wins / total) * 100) : 0;
  }

  closeModal() {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }
}
