import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ValorantTeamDetailComponent } from './team-detail/team-detail';

interface Team {
  id: string;
  name: string;
  logo: string;
  division: string;
  players: Player[];
  wins: number;
  losses: number;
}

interface Player {
  id: string;
  name: string;
  elo: string;
  characterMain: string;
}

interface Tournament {
  id: string;
  name: string;
  status: string;
  participants: number;
  startDate: string;
}

@Component({
  selector: 'app-valorant-dashboard',
  standalone: true,
  imports: [CommonModule, ValorantTeamDetailComponent],
  templateUrl: './valorant-dashboard.html',
  styleUrls: ['./valorant-dashboard.scss'],
})
export class ValorantDashboard implements OnInit {
  activeTab: 'libre' | 'equipos' | 'torneos' = 'libre';
  selectedTeam: Team | null = null;

  freePlayers: Player[] = [];
  teams: Team[] = [];
  tournaments: Tournament[] = [];

  constructor(private router: Router) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    // Datos de ejemplo - reemplazar con llamadas a API
    this.freePlayers = [
      { id: '1', name: 'Carlos González', elo: 'Radiant', characterMain: 'Jett' },
      { id: '2', name: 'María García', elo: 'Immortal', characterMain: 'Sova' },
      { id: '3', name: 'Juan López', elo: 'Diamond', characterMain: 'Viper' },
      { id: '4', name: 'Ana Martínez', elo: 'Diamond', characterMain: 'Phoenix' },
      { id: '5', name: 'Miguel Ruiz', elo: 'Platinum', characterMain: 'Cypher' },
      { id: '6', name: 'Sofia Díaz', elo: 'Platinum', characterMain: 'Omen' },
    ];

    this.teams = [
      {
        id: 'vanguard',
        name: 'Team Vanguard',
        logo: 'https://via.placeholder.com/300x300/ff4655/ffffff?text=Vanguard',
        division: 'División Elite',
        players: [
          { id: '101', name: 'Alex Torres', elo: 'Radiant', characterMain: 'Sage' },
          { id: '102', name: 'Roberto Silva', elo: 'Immortal', characterMain: 'Reyna' },
          { id: '103', name: 'Laura Moreno', elo: 'Immortal', characterMain: 'Breach' },
          { id: '104', name: 'Diego Ponce', elo: 'Diamond', characterMain: 'Skye' },
          { id: '105', name: 'Elena Vargas', elo: 'Diamond', characterMain: 'Kay/o' },
        ],
        wins: 15,
        losses: 2,
      },
      {
        id: 'apex',
        name: 'Apex Legends',
        logo: 'https://via.placeholder.com/300x300/ff6b6b/ffffff?text=Apex',
        division: 'División A',
        players: [
          { id: '201', name: 'Andrea Guerrero', elo: 'Immortal', characterMain: 'Astra' },
          { id: '202', name: 'Luis Mendez', elo: 'Diamond', characterMain: 'Harbor' },
          { id: '203', name: 'Patricia Rojas', elo: 'Diamond', characterMain: 'Neon' },
          { id: '204', name: 'Marco Acuña', elo: 'Platinum', characterMain: 'Raze' },
        ],
        wins: 11,
        losses: 6,
      },
      {
        id: 'strike',
        name: 'Strike Force',
        logo: 'https://via.placeholder.com/300x300/ff8787/ffffff?text=Strike',
        division: 'División A',
        players: [
          { id: '301', name: 'Victoria Flores', elo: 'Immortal', characterMain: 'Chamber' },
          { id: '302', name: 'Fernando Castro', elo: 'Diamond', characterMain: 'Brimstone' },
          { id: '303', name: 'Isabel Muñoz', elo: 'Diamond', characterMain: 'Fade' },
        ],
        wins: 13,
        losses: 4,
      },
      {
        id: 'nexus',
        name: 'Nexus Gaming',
        logo: 'https://via.placeholder.com/300x300/ffb3b3/ffffff?text=Nexus',
        division: 'División B',
        players: [
          { id: '401', name: 'Rodrigo Herrera', elo: 'Diamond', characterMain: 'Sage' },
          { id: '402', name: 'Carolina Salazar', elo: 'Platinum', characterMain: 'Killjoy' },
          { id: '403', name: 'Pablo Huanca', elo: 'Platinum', characterMain: 'Viper' },
        ],
        wins: 8,
        losses: 9,
      },
    ];

    this.tournaments = [
      {
        id: 'nationals',
        name: 'Valorant Champions Spain',
        status: 'En curso',
        participants: 16,
        startDate: '2026-02-01',
      },
      {
        id: 'regional',
        name: 'Regional Valorant Pro',
        status: 'En curso',
        participants: 12,
        startDate: '2026-02-10',
      },
      {
        id: 'friendly',
        name: 'Valorant Open Cup',
        status: 'Por comenzar',
        participants: 8,
        startDate: '2026-03-01',
      },
    ];
  }

  switchTab(tab: 'libre' | 'equipos' | 'torneos') {
    this.activeTab = tab;
    this.selectedTeam = null;
  }

  selectTeam(team: Team) {
    this.selectedTeam = team;
  }

  closeTeamDetail() {
    this.selectedTeam = null;
  }

  backToSelector() {
    this.router.navigate(['/selector']);
  }
}
