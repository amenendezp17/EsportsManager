import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

interface UserProfile {
  name: string;
  team: string;
  game: string;
  winRate: number;
  role: 'Jugador' | 'Manager';
  avatar?: string;
}

@Component({
  selector: 'app-profile-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-backdrop" (click)="onBackdropClick($event)">
      <div class="modal-content" *ngIf="user">
        <button class="close-btn" (click)="closeModal()">✕</button>
        
        <div class="profile-header">
          <div class="avatar">{{ user.name.charAt(0).toUpperCase() }}</div>
          <div class="user-title">
            <h2>{{ user.name }}</h2>
            <span class="role-badge" [ngClass]="user.role === 'Manager' ? 'manager' : 'player'">
              {{ user.role }}
            </span>
          </div>
        </div>

        <div class="profile-info">
          <div class="info-item">
            <span class="label">Equipo</span>
            <span class="value">{{ user.team }}</span>
          </div>
          <div class="info-item">
            <span class="label">Juego</span>
            <span class="value">{{ user.game }}</span>
          </div>
          <div class="info-item">
            <span class="label">Win Rate</span>
            <span class="value win-rate">{{ user.winRate }}%</span>
          </div>
        </div>

        <button class="close-modal-btn" (click)="closeModal()">Cerrar</button>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 2000;
      animation: fadeIn 0.3s ease-out;
    }

    .modal-content {
      background: linear-gradient(135deg, rgba(14, 139, 149, 0.15) 0%, rgba(28, 163, 173, 0.1) 100%);
      border: 2px solid rgba(28, 163, 173, 0.3);
      border-radius: 20px;
      padding: 40px;
      max-width: 400px;
      width: 90%;
      position: relative;
      backdrop-filter: blur(10px);
      box-shadow: 0 8px 32px 0 rgba(14, 139, 149, 0.2);
      animation: slideDown 0.4s ease-out;
    }

    .close-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background: none;
      border: none;
      font-size: 28px;
      color: #0e8b95;
      cursor: pointer;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: all 0.3s ease;
    }

    .close-btn:hover {
      background: rgba(14, 139, 149, 0.2);
      transform: rotate(90deg);
    }

    .profile-header {
      display: flex;
      gap: 20px;
      align-items: center;
      margin-bottom: 30px;
      padding-bottom: 30px;
      border-bottom: 2px solid rgba(28, 163, 173, 0.2);
    }

    .avatar {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0e8b95 0%, #1ca3ad 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
      font-weight: 700;
      color: #fff;
      box-shadow: 0 4px 15px rgba(14, 139, 149, 0.3);
      flex-shrink: 0;
    }

    .user-title {
      flex: 1;
    }

    .user-title h2 {
      margin: 0 0 8px 0;
      font-size: 24px;
      font-weight: 700;
      color: #fff;
    }

    .role-badge {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #fff;

      &.player {
        background: rgba(28, 163, 173, 0.4);
        border: 1px solid rgba(28, 163, 173, 0.6);
      }

      &.manager {
        background: rgba(255, 102, 0, 0.4);
        border: 1px solid rgba(255, 102, 0, 0.6);
      }
    }

    .profile-info {
      display: flex;
      flex-direction: column;
      gap: 16px;
      margin-bottom: 30px;
    }

    .info-item {
      background: rgba(14, 139, 149, 0.15);
      border: 1px solid rgba(28, 163, 173, 0.3);
      border-radius: 12px;
      padding: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: all 0.3s ease;

      &:hover {
        border-color: rgba(28, 163, 173, 0.6);
        background: rgba(14, 139, 149, 0.25);
      }
    }

    .label {
      font-size: 13px;
      color: rgba(255, 255, 255, 0.6);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-weight: 600;
    }

    .value {
      font-size: 16px;
      font-weight: 600;
      color: #0e8b95;
    }

    .win-rate {
      font-size: 18px;
      background: linear-gradient(135deg, #0e8b95 0%, #1ca3ad 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .close-modal-btn {
      width: 100%;
      padding: 12px 20px;
      background: linear-gradient(135deg, #0e8b95 0%, #1ca3ad 100%);
      border: none;
      border-radius: 12px;
      color: #fff;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-family: inherit;

      &:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(14, 139, 149, 0.4);
      }

      &:active {
        transform: translateY(0);
      }
    }

    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @media (max-width: 480px) {
      .modal-content {
        padding: 25px;
      }

      .avatar {
        width: 70px;
        height: 70px;
        font-size: 28px;
      }

      .user-title h2 {
        font-size: 20px;
      }

      .value {
        font-size: 14px;
      }
    }
  `],
})
export class ProfileModalComponent {
  @Input() user!: UserProfile;
  @Output() close = new EventEmitter<void>();

  closeModal() {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }
}
