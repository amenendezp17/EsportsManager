import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
})
export class Login {
  username: string = '';
  password: string = '';
  isLoading: boolean = false;
  error: string = '';
  showPassword: boolean = false;

  constructor(private router: Router) {}

  onSubmit(form: NgForm) {
    if (!form.valid) return;

    this.error = '';
    this.isLoading = true;

    // Simulate API call (replace with real authentication)
    setTimeout(() => {
      const credentials = { username: this.username, password: this.password };
      console.log('Login attempt', credentials);

      // TODO: Replace with actual backend call
      // Example:
      // this.authService.login(credentials).subscribe(
      //   (response) => {
      //     this.isLoading = false;
      //     // Handle successful login (navigate, save token, etc.)
      //   },
      //   (error) => {
      //     this.isLoading = false;
      //     this.error = 'Usuario o contraseña incorrectos';
      //   }
      // );

      this.isLoading = false;
      // Navigate to game selector after successful login
      this.router.navigate(['/selector']);
    }, 1500);
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  clearError() {
    this.error = '';
  }
}
