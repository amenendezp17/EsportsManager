import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  constructor() {}

  // Stub: replace with HTTP call to backend when available
  getUsuarios(): Observable<any[]> {
    const sample = [
      { id: 1, username: 'admin', email: 'admin@example.com', rol: 'admin' }
    ];
    return of(sample);
  }
}
